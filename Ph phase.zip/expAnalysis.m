
opts = detectImportOptions('IQstab.csv');
preview('IQstab.csv',opts)

M = readtimetable('IQstab.csv', 'TimeStep', seconds(0.1))

Q = M.AD3_0_ai0;
I = M.AD3_0_ai1;

N = length(Q)
STDmean = mean(Q)/sqrt(N)
dof = N - 1; %Depends on the problem but this is standard for a CI around a mean.
studentst = tinv([.025 0.975],dof) %tinv is the student's t lookup table for the two-tailed 95% CI ...
QCI = studentst*STDmean
Qmean = mean(Q)